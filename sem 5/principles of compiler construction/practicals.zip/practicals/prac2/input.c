#include <stdio.h>
void main(int a)
{
    /* HELLO This is a comment*/
    int a, b, c;
    a = 1;
    b = 2;
    if (a > b)
        c = 0;
    else
        c = -1;

    printf("The value of c: %d", c);
    for (int i = 0; i < 5; i++)
        i++;
    return 0;
}

